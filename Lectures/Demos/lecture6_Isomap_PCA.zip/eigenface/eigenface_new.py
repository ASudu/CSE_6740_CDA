############################################################################
# The codes are based on Python2.7. 
# Please install numpy, scipy, matplotlib, PIL, skimage packages before using.
# Make sure os package could work.  
# Thank you for your suggestions!
#
# @version 1.0
# @author CSE6740/CS7641 TA
############################################################################
import numpy as np
import matplotlib.pyplot as plt
import os
from scipy import ndimage
from scipy import linalg
from skimage import transform

# histogram equalization
def histeq(im, nbr_bins):

    #get image histogram
    imhist,bins = np.histogram(im.flatten(),nbr_bins,normed=True)
    cdf = imhist.cumsum() #cumulative distribution function
    cdf = 255 * cdf / cdf[-1] #normalize

    #use linear interpolation of cdf to find new pixel values
    im2 = np.interp(im.flatten(),bins[:-1],cdf)

    return im2.reshape(im.shape) 

# read the file
faces = os.listdir('training')
Totalimage = len(faces)

irow = 65
icol = 65

# Chosen std and mean. 
# It can be any number that it is close to the std and  mean of most of the images.
um = 100
ustd = 80

# Stack vectors of grayscale images into data_raw
data_raw = np.zeros((irow * icol, Totalimage))
for i in range(0, Totalimage):
    path = 'training/' + faces[i]
    # image processoing
    image = ndimage.imread(path, flatten = True) # Convert into a vector  
   
    #---------------------------
    #two choices to resize the images:
    #misc.imresize() will rescale the images while transform.resize won't
    #---------------------------
    resized_image = transform.resize(image, (irow, icol), order=1, preserve_range=True)
    #resized_image = misc.imresize(image, np.array([irow, icol]))
    
    resized_image = resized_image.T.reshape(irow * icol,)
    data_raw[:, i] = resized_image # "data_raw" is our orignial dataset size
    
# Here we change the mean and std of all images. We normalize all images.
# This is done to reduce the error due to lighting conditions.
data = np.zeros((irow * icol, Totalimage))
for i in range(0, data_raw.shape[1]):
    temp = data_raw[:,i].astype(float)
    m = np.mean(temp)
    st = np.std(temp, ddof=1)
    data[:, i] = (temp - m) * ustd / (st + um)

# obtain the mean image
mean_face = np.mean(data, axis = 1)
temp_mean = mean_face.reshape(icol, irow)
temp_mean = temp_mean.T
plt.figure(1)
plt.ion()
plt.imshow(temp_mean / 255, cmap='gray')
plt.axis('off')
plt.title('Mean Face', fontsize=14)
plt.show()
plt.ioff()

# reduce the mean
data_C = data - mean_face.reshape(mean_face.shape[0], 1)

# here, instead of calculating eigenvectors of data_C*data_C', 
# we calculate the eigenvectors of data_C'*data_C
L = data_C.T.dot(data_C)
S, V = np.linalg.eig(L.astype('float'))
# Sort and eliminate those whose eigenvalue is zero
sortidx = S.argsort()[::-1] 
d = S[sortidx]
v = V[:,sortidx]
i = v.shape[1] - 1
while (d[i] <= 0):
    v = np.delete(v, i, axis = 1)
    d = np.delete(d, i) 
    i = i - 1   

# Normalization of eigenvectors
for i in range(0, v.shape[1]):  # access each column
    kk = v[:, i]
    temp = np.sqrt(np.sum(np.power(kk, 2)))
    v[:, i] = v[:, i] / temp
 
# Eigenvectors of C matrix
u = np.zeros((irow * icol, v.shape[1]))
for i in range(0, v.shape[1]):
    
    temp = np.sqrt(d[i])
    u[:, i] = (data_C.dot(v[:, i])) / temp
    
# Normalization of eigenvectors
for i in range(0, u.shape[1]):
    kk = u[:, i]
    temp = np.sqrt(np.sum(np.power(kk, 2)))
    u[:, i] = u[:, i] / temp

# show the first K=6 eigenfaces
plt.figure(2)
plt.ion()
K = 6
for i in range(0, K):
    plt.subplot(2,3,i + 1)
    plt.axis('off')
    temp = u[:, i].reshape(icol, irow)
    temp = temp.T
    temp = histeq(temp, 255)   
    plt.imshow(temp, cmap='gray')
    if (i == 2):
        plt.title('Eigenfaces', fontsize=18)
plt.show()
plt.ioff()


# Find the weight of each face in the training set.
omega = np.zeros((Totalimage, Totalimage))
for h in range(0, data_C.shape[1]):
    WW = np.zeros((Totalimage, ))
    for i in range(0, u.shape[1]):
        t = u[:, i].T
        WeightOfImage = np.dot(t, data_C[:, h].T) 
        WW[i] = WeightOfImage
    omega[:, h] = WW


# Acquire new image

# Professor and TAs image names
# The testing file includes the following images
# Le.bmp
# Amir.bmp
# bo.bmp
# Kaushik.bmp
# Shuang.bmp
# Ashwin.bmp
# Chuchu.bmp
# Hanjun.bmp
# Rakshit.bmp


# read the file
Testing = os.listdir('testing')
InputImage = raw_input('Please enter the name of the image and its extension: ')
path = 'testing/' + InputImage
InputImage = ndimage.imread(path, flatten = True)
InputImage = transform.resize(InputImage, (irow, icol), order=1, preserve_range=True)

plt.figure(3)
plt.ion()
plt.subplot(121)
plt.imshow(InputImage, cmap='gray')
plt.title('Input image', fontsize=18)
plt.axis('off')

InImage = InputImage.T.reshape(irow * icol,)
temp = InImage
me = np.mean(temp)
st = np.std(temp)
temp = (temp - me) * ustd / (st + um)
NormImage = temp
Difference = temp - mean_face


p = np.zeros((u.shape[1], 1))
aa = u.shape[1]
for i in range(0, aa):
    pare = np.dot(NormImage, u[:, i])
    p[i] = pare 
    
ReshapedImage = mean_face + u[:, 0:aa].dot(p).squeeze() # m is the mean image, u is the eigenvector
ReshapedImage = ReshapedImage.reshape(icol, irow) 
ReshapedImage = ReshapedImage.T
# show the reconstructed image.
plt.subplot(122)
plt.imshow(ReshapedImage, cmap='gray')
plt.title('Reconstructed image', fontsize = 18)
plt.axis('off')
plt.show()
plt.ioff()



InImWeight = np.zeros((Totalimage,))
for i in range(0, u.shape[1]):
    t = u[:, i].T
    WeightOfInputImage = np.dot(t, Difference.T)
    InImWeight[i] = WeightOfInputImage


x = np.linspace(1, u.shape[1], u.shape[1])
plt.figure(4)
plt.ion()
plt.subplot(121)
plt.stem(x, InImWeight[0: u.shape[1]])
plt.title('Weight of Input Face', fontsize = 14)

# Find Euclidean distance
e = np.zeros((Totalimage,))
for i in range(0, omega.shape[1]):
    q = omega[:, i]
    DiffWeight = InImWeight - q
    mag = linalg.norm(DiffWeight)
    e[i] = mag
    
kk = np.linspace(1, Totalimage, Totalimage)
plt.subplot(122)
plt.stem(kk,e)  
plt.title('Eucledian distance of input image', fontsize = 14)

MaximumValue = np.max(e)
MinimumValue = np.min(e)
print MaximumValue
print MinimumValue

plt.show()
plt.ioff()
plt.show()