############################################################################
# The codes are based on Python2.7. 
# Please install numpy, scipy, matplotlib, skimage, PIL packages before using.
# Make sure os package could work.  
# Thank you for your suggestions!
#
# @version 1.0
# @author CSE6740/CS7641 TA
######################################################################
import numpy as np
import matplotlib.pyplot as plt
import show_image
import os
from scipy import ndimage
from scipy import misc
from skimage import transform

# read the file
faces = os.listdir('training')
Totalimage = len(faces)

irow = 65
icol = 65
data_raw = np.zeros((irow * icol, Totalimage))

for i in range(0, Totalimage):
    path = 'training/' + faces[i]
    image = ndimage.imread(path, flatten = True)
    #resized_image = misc.imresize(image, np.array([irow, icol]))
    resized_image = transform.resize(image, (irow, icol), order=1, preserve_range=True)
    resized_image = resized_image.reshape(irow * icol,1)
    # "data_raw" is our orignial dataset size: 4225 * 637
    data_raw[:, i] = resized_image.squeeze()
    
plt.figure(1)
plt.ion()
show_image.show_image_function(data_raw.T, irow, icol)
plt.axis('off')
plt.show()
plt.ioff()

data = data_raw.astype(float)

# obtain the mean image
mean_face = np.mean(data, axis=1)
mean_face = mean_face.reshape(1, mean_face.shape[0])
plt.figure(2)
plt.ion()
show_image.show_image_function(mean_face, irow, icol)
plt.title('Mean Face', fontsize=14)
plt.axis('off')
plt.show()
plt.ioff()

# reduce the mean
data_C = data - mean_face.T

# # note that left singular vector of data_C is equal to eigenvector of
# data_C * data_C'; In this problem, svd is much faster. 
# L=data_C*data_C';
# [vv dd]=eig(L);

u, s, v = np.linalg.svd(data_C / Totalimage) 
#ss = np.diag(s)

x = np.linspace(1, s.shape[0], s.shape[0])
plt.figure(3)
plt.ion()
plt.subplot(121)
plt.plot( x, np.power(s, 2)/np.sum(np.power(s, 2))  )
plt.title('Eigenspectrum')
plt.subplot(122)
plt.plot( x, np.cumsum( np.power(s, 2)/np.sum(np.power(s, 2)) ) ) 
plt.title('Cumulative Sum of Eigenspectrum')
plt.show()
plt.ioff()

# show the first K=6 eigenfaces
fig = plt.figure(4)
plt.ion()
K=20
for i in range(0, K):
    temp = u[:,i].reshape(irow, icol)
    temp = 255 * (temp - temp.min())/(temp.max()-temp.min())
    temp = temp.reshape(1, irow * icol)
    fig.add_subplot(4,5,(i + 1))
    show_image.show_image_function(temp, irow, icol)
    plt.axis('off')
    if (i == 0):
        plt.title('Eigenfaces')
plt.show()
plt.ioff()

# pick 60 components to preserve about 95% variance of the data; 
component_no = 100
omega = u[:,0:component_no].T.dot(data_C)

selected_i = 94
reconstructed_I = mean_face

plt.figure(5)
plt.ion()
reconstructed_I = reconstructed_I + omega[0, selected_i] * u[:, 0]
temp = 255 * (reconstructed_I - reconstructed_I.min())/(reconstructed_I.max() - reconstructed_I.min())
temp_image = temp
image_show = plt.imshow(temp.reshape(irow, icol), cmap='gray')
plt.title(str(1))
plt.pause(0.001)
for i in range(1, component_no):
    reconstructed_I = reconstructed_I + omega[i, selected_i] * u[:, i]
    temp = 255 * (reconstructed_I - reconstructed_I.min())/(reconstructed_I.max() - reconstructed_I.min() )
    temp_image = np.concatenate((temp_image, temp), axis = 0)
    image_show.set_data(temp.reshape(irow, icol))
    plt.title(str(i+1))
    plt.axis('off')
    plt.pause(0.001)   
    if (np.mod(i+1, 20) == 0):
        raw_input('press any key to continue\n')
plt.ioff()

plt.figure(6)
plt.ion()
show_image.show_image_function(temp_image, irow, icol)
plt.axis('off')
plt.show()
plt.ioff()

### Acquire new image

# Professor and TAs image names
# The testing file includes the following images
# Le.bmp
# Amir.bmp
# Bo.bmp
# Kaushik.bmp
# Shuang.bmp

# read the file
Testing = os.listdir('testing')
#InputImage = raw_input('Please enter the name of the image and its extension \n');  
InputImage = 'shuang.bmp'
path = 'testing/' + InputImage
InputImage = ndimage.imread(path, flatten = True)

InputImage = misc.imresize(InputImage, np.array([irow, icol]))
plt.figure(7)
plt.ion()
plt.imshow(InputImage, cmap='gray')
raw_input('press any key to continue\n')
newdata = InputImage.reshape(irow * icol, 1).astype(float)
plt.axis('off')
plt.show()
plt.ioff()

component_no = 100

omega = u.T.dot(newdata - mean_face.T)
omega.shape = (omega.shape[0],)

reconstructed_I = mean_face
plt.figure(8)
plt.ion()
reconstructed_I = reconstructed_I + omega[0] * u[:, 0]
temp = 255 * (reconstructed_I - reconstructed_I.min())/(reconstructed_I.max() - reconstructed_I.min())
image_show = plt.imshow(temp.reshape(irow, icol), cmap='gray')
plt.title(str(1))
plt.pause(0.001)
for i in range(1, component_no):
    reconstructed_I = reconstructed_I + omega[i] * u[:, i]
    temp = 255 * (reconstructed_I - reconstructed_I.min())/(reconstructed_I.max() - reconstructed_I.min() )
    image_show.set_data(temp.reshape(irow, icol))
    plt.title(str(i+1))
    plt.axis('off')
    plt.pause(0.001)   
plt.ioff()
plt.show()
